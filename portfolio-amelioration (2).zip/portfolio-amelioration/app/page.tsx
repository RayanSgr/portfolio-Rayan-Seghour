"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { Satellite, Network, Mail, Phone, Menu, X, Code, ChevronDown, ExternalLink, Star } from "lucide-react"

export default function Portfolio() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState("home")
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })

  const skills = [
    { name: "Administration Linux", level: 75 },
    { name: "Routage & Switching", level: 70 },
    { name: "Sécurité réseau", level: 65 },
    { name: "Configuration de serveurs", level: 70 },
    { name: "Virtualisation", level: 80 },
    { name: "HTML/CSS", level: 60 },
  ]

  const veilleData = [
    {
      date: "20 MAR",
      title: "Digital Twin IoT : Siemens révolutionne l'industrie",
      content:
        "Siemens présente sa plateforme de jumeaux numériques IoT permettant la simulation en temps réel de millions d'objets connectés industriels.",
      source: "TechCrunch IoT",
      sourceUrl: "https://techcrunch.com/tag/internet-of-things/",
      category: "Industrie 4.0",
    },
    {
      date: "08 AVR",
      title: "5G-Advanced : Nouvelle ère pour l'IoT massif",
      content:
        "Le standard 5G-Advanced est finalisé, permettant la connexion simultanée de 8 millions d'objets IoT par km² avec une efficacité énergétique 8x supérieure.",
      source: "The Verge Tech",
      sourceUrl: "https://www.theverge.com/tech",
      category: "Connectivité",
    },
    {
      date: "15 MAI",
      title: "Protocole IoT-Mesh 2.5 : Communication autonome",
      content:
        "Le nouveau standard IEEE permet une communication inter-objets sans infrastructure centralisée, avec une portée étendue à 1.5km en zone urbaine.",
      source: "IEEE Spectrum",
      sourceUrl: "https://spectrum.ieee.org/topic/telecom/internet/",
      category: "Protocoles",
    },
  ]

  useEffect(() => {
    const handleScroll = () => {
      const sections = ["home", "about", "projects", "stages", "formation", "contact"]
      const current = sections.find((section) => {
        const element = document.getElementById(section)
        if (element) {
          const rect = element.getBoundingClientRect()
          return rect.top <= 100 && rect.bottom >= 100
        }
        return false
      })
      if (current) setActiveSection(current)
    }

    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }

    window.addEventListener("scroll", handleScroll)
    window.addEventListener("mousemove", handleMouseMove)
    return () => {
      window.removeEventListener("scroll", handleScroll)
      window.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setIsMenuOpen(false)
  }

  const handleContactClick = () => {
    window.open("mailto:rayanseghour@gmail.com", "_blank")
  }

  const handleSourceClick = (url: string, e: React.MouseEvent) => {
    e.stopPropagation()
    window.open(url, "_blank", "noopener,noreferrer")
  }

  return (
    <div className="min-h-screen bg-white relative overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex justify-between items-center h-16">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm">
              SR
            </div>

            <div className="hidden md:block">
              <div className="flex items-center space-x-8">
                {[
                  { id: "home", label: "Accueil" },
                  { id: "about", label: "À propos" },
                  { id: "projects", label: "Projets" },
                  { id: "stages", label: "Stages" },
                  { id: "contact", label: "Contact" },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className={`text-sm font-medium transition-colors ${
                      activeSection === item.id ? "text-blue-600" : "text-gray-600 hover:text-gray-900"
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="md:hidden">
              <Button variant="ghost" size="sm" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200">
            <div className="px-6 py-4 space-y-3">
              {[
                { id: "home", label: "Accueil" },
                { id: "about", label: "À propos" },
                { id: "projects", label: "Projets" },
                { id: "stages", label: "Stages" },
                { id: "contact", label: "Contact" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="block text-sm font-medium text-gray-700 hover:text-gray-900 w-full text-left"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section
        id="home"
        className="pt-16 min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50"
      >
        <div className="max-w-4xl mx-auto text-center px-6">
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full text-sm font-medium text-gray-700 shadow-sm">
                <Star className="h-4 w-4 text-yellow-500" />
                Étudiant BTS SIO - Spécialiste Réseaux
              </div>
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900">
                Seghour{" "}
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Rayan
                </span>
              </h1>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Passionné par les infrastructures réseau et les technologies émergentes
              </p>
            </div>
            <div className="flex justify-center">
              <Button
                onClick={() => scrollToSection("about")}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-full"
              >
                Découvrir mon parcours
                <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16">
            <div className="space-y-8">
              <h2 className="text-4xl font-bold text-gray-900">À propos</h2>
              <div className="space-y-6 text-gray-600 text-lg">
                <p>
                  Actuellement en première année de BTS SIO option SISR, je me passionne pour l'univers des réseaux
                  informatiques et des infrastructures.
                </p>
                <p>
                  Ma curiosité naturelle m'amène à explorer les dernières innovations, notamment dans l'IoT et
                  l'intelligence artificielle.
                </p>
              </div>
            </div>

            <div className="space-y-8">
              <h3 className="text-2xl font-semibold text-gray-900">Compétences techniques</h3>
              <div className="space-y-6">
                {skills.map((skill, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium text-gray-700">{skill.name}</span>
                      <span className="text-sm text-gray-500">{skill.level}%</span>
                    </div>
                    <Progress value={skill.level} className="h-2" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-24 px-6 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Projets</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Découvrez mes réalisations techniques et ma veille technologique
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Projet KOO2fourchette */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="h-32 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                  <Code className="h-8 w-8 text-orange-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">KOO2fourchette</h3>
                <p className="text-sm text-gray-600 mb-4">Site de recettes culinaires</p>
                <div className="flex flex-wrap gap-2">
                  {["HTML5", "CSS3", "JavaScript", "PHP"].map((tech) => (
                    <Badge key={tech} variant="secondary" className="text-xs">
                      {tech}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Veille Technologique */}
            <Dialog>
              <DialogTrigger asChild>
                <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6">
                    <div className="h-32 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                      <Satellite className="h-8 w-8 text-blue-600" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">Veille Technologique IoT</h3>
                    <p className="text-sm text-gray-600 mb-4">Innovations IoT 2025</p>
                    <Badge variant="secondary" className="text-xs">
                      5 actualités
                    </Badge>
                  </CardContent>
                </Card>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Veille Technologique IoT 2025</DialogTitle>
                </DialogHeader>
                <div className="space-y-6 mt-6">
                  <p className="text-gray-600">
                    Suivi des dernières innovations dans l'Internet des Objets de mars à septembre 2025.
                  </p>

                  <div className="space-y-4">
                    {veilleData.map((item, index) => (
                      <Card key={index} className="border-l-4 border-blue-500">
                        <CardContent className="p-4">
                          <div className="flex gap-4">
                            <div className="bg-blue-600 text-white px-3 py-1 rounded text-xs font-bold min-w-fit">
                              {item.date}
                            </div>
                            <div className="flex-1">
                              <h4 className="font-semibold text-gray-900 mb-2">{item.title}</h4>
                              <p className="text-gray-600 text-sm mb-2">{item.content}</p>
                              <div className="flex items-center gap-2 text-xs">
                                <ExternalLink className="h-3 w-3" />
                                <button
                                  onClick={(e) => handleSourceClick(item.sourceUrl, e)}
                                  className="text-blue-600 hover:underline"
                                >
                                  {item.source}
                                </button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            {/* Infrastructure Réseau */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="h-32 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <Network className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Infrastructure Réseau</h3>
                <p className="text-sm text-gray-600 mb-4">Architecture avec VLANs</p>
                <div className="flex flex-wrap gap-2">
                  {["Cisco", "pfSense", "Linux"].map((tech) => (
                    <Badge key={tech} variant="secondary" className="text-xs">
                      {tech}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stages Section */}
      <section id="stages" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Expérience de Stage</h2>
          </div>

          <Card className="max-w-4xl mx-auto">
            <CardContent className="p-0">
              <div className="flex flex-col md:flex-row">
                <div className="bg-green-600 text-white p-8 md:min-w-[200px]">
                  <Network className="h-8 w-8 mb-4" />
                  <div className="text-2xl font-bold">2025</div>
                  <div className="text-sm opacity-90">Mai - Juillet</div>
                  <div className="text-xs bg-white/20 px-2 py-1 rounded mt-2 inline-block">Terminé</div>
                </div>
                <div className="flex-1 p-8">
                  <h3 className="text-2xl font-semibold text-gray-900 mb-2">Stage Technicien Réseau</h3>
                  <p className="text-green-600 font-medium mb-2">Giftasso (développée par Metacard)</p>
                  <p className="text-gray-600 mb-6">
                    Stage de 3 mois axé sur l'administration réseau, le développement d'outils de vente et la
                    maintenance d'infrastructures e-commerce.
                  </p>

                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Missions réalisées :</h4>
                      <ul className="text-gray-600 space-y-1 text-sm">
                        <li>• Configuration et maintenance des infrastructures réseau</li>
                        <li>• Développement du processus de vente final</li>
                        <li>• Participation au développement du site marchand</li>
                        <li>• Sécurisation des transactions et données clients</li>
                        <li>• Monitoring et optimisation réseau</li>
                      </ul>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {["Réseaux", "E-commerce", "Sécurité", "Vente", "Linux"].map((skill) => (
                        <Badge key={skill} className="bg-green-100 text-green-800">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 px-6 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Contact</h2>
            <p className="text-gray-600">N'hésitez pas à me contacter pour toute opportunité</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card
              className="hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => window.open("mailto:rayanseghour@gmail.com")}
            >
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Email</h3>
                <p className="text-gray-600">rayanseghour@gmail.com</p>
              </CardContent>
            </Card>

            <Card
              className="hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => window.open("tel:+33767090441")}
            >
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Phone className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Téléphone</h3>
                <p className="text-gray-600">+33 7 67 09 04 41</p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <Button
              onClick={handleContactClick}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3"
            >
              <Mail className="h-5 w-5 mr-2" />
              Envoyer un message
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-gray-300">&copy; 2025 Seghour Rayan. Tous droits réservés.</p>
        </div>
      </footer>
    </div>
  )
}
